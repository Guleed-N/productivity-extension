let timer;
let minutes = 25;
let seconds = 0;
let isRunning = false;
let port;

function updateTimerDisplay() {
  if (port) {
    port.postMessage({ action: 'updateTimer', minutes, seconds });
  }
}

function startTimer() {
  if (!isRunning) {
    timer = setInterval(() => {
      if (minutes === 0 && seconds === 0) {
        clearInterval(timer);
        isRunning = false;
        alert("Pomodoro session completed!");
      } else {
        if (seconds === 0) {
          minutes--;
          seconds = 59;
        } else {
          seconds--;
        }
        updateTimerDisplay();
      }
    }, 1000);
    isRunning = true;
  }
}

function resetTimer() {
  clearInterval(timer);
  isRunning = false;
  minutes = 25;
  seconds = 0;
  updateTimerDisplay();
}

chrome.runtime.onConnect.addListener((connectedPort) => {
  port = connectedPort;

  port.onMessage.addListener((message) => {
    if (message.action === 'startTimer') {
      startTimer();
    } else if (message.action === 'resetTimer') {
      resetTimer();
    } else if (message.action === 'getInitialTimer') {
      port.postMessage({ action: 'updateTimer', minutes, seconds });
    }
  });
});

