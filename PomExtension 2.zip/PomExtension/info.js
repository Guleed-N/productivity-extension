document.addEventListener("DOMContentLoaded", function () {
    chrome.storage.sync.get('darkMode', (result) => {
      if (result.darkMode) {
        document.body.classList.add('dark-mode');
      }
    });
    document.getElementById("backButton").addEventListener("click", goBack);
  });
  function goBack() {
    window.history.back();
  }
  