document.addEventListener("DOMContentLoaded", function () {
  const port = chrome.runtime.connect({ name: "popup" });
  const progressBar = document.getElementById("progress-bar");

  function updateTimerDisplay(minutes, seconds) {
    document.getElementById("timer").innerText = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }

  function startTimer() {
    port.postMessage({ action: 'startTimer' });
  }

  function resetTimer() {
    port.postMessage({ action: 'resetTimer' });
  }

  function toggleDarkMode() {
    var body = document.body;
    var isDarkMode = body.classList.contains('dark-mode');

    if (isDarkMode) {
      body.classList.remove('dark-mode');
      chrome.storage.sync.set({ darkMode: false });
    } else {
      body.classList.add('dark-mode');
      chrome.storage.sync.set({ darkMode: true });
    }
  }

  // Add click event listener to toggle dark mode
  document.getElementById("toggleButton").addEventListener("click", toggleDarkMode);

  // Add event listeners for the timer buttons
  document.getElementById("startBtn").addEventListener("click", startTimer);
  document.getElementById("resetBtn").addEventListener("click", resetTimer);

  // Retrieve dark mode preference and apply it
  chrome.storage.sync.get('darkMode', (result) => {
    if (result.darkMode) {
      document.body.classList.add('dark-mode');
    }
  });

  // Update the initial timer display
  port.postMessage({ action: 'getInitialTimer' });

  // Listen for updates from the background script
  port.onMessage.addListener((message) => {
    if (message.action === 'updateTimer') {
      updateTimerDisplay(message.minutes, message.seconds);
    }
  });

  // Function to handle clicking the Info button
  function handleInfoButtonClick() {
    // Trigger a click on the hidden infoLink
    document.getElementById('infoLink').click();
  }

  // Add click event listener to the Info button
  document.getElementById("infoBtn").addEventListener("click", handleInfoButtonClick);
});